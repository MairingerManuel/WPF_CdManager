﻿using CdManager.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_CdManager
{
    /// <summary>
    /// Interaction logic for AddCdWindow.xaml
    /// </summary>
    public partial class AddCdWindow : Window
    {
        public AddCdWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(AddCdWindow_loaded);
        }

        void AddCdWindow_loaded(object sender, RoutedEventArgs e)
        {
            btsave.Click += new RoutedEventHandler(btsave_Click);
            btCancel.Click += new RoutedEventHandler(btCancel_Click);
        }

        void btCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        void btsave_Click(object sender, RoutedEventArgs e)
        {
            Cd newCd = new Cd();
            newCd.AlbumTitle = tbTitle.Text;
            newCd.Artist = tbArtist.Text;
            Repository.GetInstance().AddCd(newCd);
            Close();
        }
    }
}
